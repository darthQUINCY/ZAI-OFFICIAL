import { motion } from 'framer-motion';
import { ShoppingCart, IndianRupee } from 'lucide-react';
import { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <div className="bg-gray-900 rounded-2xl overflow-hidden shadow-[0_4px_30px_rgba(0,0,0,0.5)] border border-gray-800 flex flex-col group relative h-full">
      <div className="relative h-56 overflow-hidden flex-shrink-0">
        <motion.div 
          className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-10"
          initial={{ opacity: 0 }}
          whileHover={{ opacity: 1 }}
        />
        <img 
          src={product.imageUrl} 
          alt={product.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-4 right-4 z-20 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-white uppercase tracking-wider">
          {product.category}
        </div>
      </div>
      
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-bold text-white mb-2 leading-tight group-hover:text-indigo-400 transition-colors">
          {product.title}
        </h3>
        <p className="text-gray-400 text-sm mb-6 flex-grow line-clamp-2">
          {product.description}
        </p>
        
        <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-800">
          <div className="flex items-center text-2xl font-black text-white">
            <IndianRupee className="w-5 h-5 mr-1 text-indigo-500" />
            {product.price}
          </div>
          
          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="bg-indigo-600 hover:bg-indigo-500 text-white p-3 rounded-xl transition-colors shadow-lg shadow-indigo-500/30"
          >
            <ShoppingCart className="w-5 h-5" />
          </motion.button>
        </div>
      </div>
    </div>
  );
}
