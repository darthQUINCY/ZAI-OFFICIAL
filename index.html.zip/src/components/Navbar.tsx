import React from 'react';
import { motion } from 'framer-motion';
import { Gamepad2, ShoppingCart, Menu, X } from 'lucide-react';

export function Navbar() {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <nav className="fixed w-full z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2"
          >
            <Gamepad2 className="w-8 h-8 text-indigo-500" />
            <span className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-500 bg-clip-text text-transparent tracking-wider">
              ZAI OFFICIAL
            </span>
          </motion.div>
          
          <div className="hidden md:block">
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="ml-10 flex items-baseline space-x-8"
            >
              <a href="#home" className="hover:text-indigo-400 text-white px-3 py-2 rounded-md text-sm font-medium transition-colors">Home</a>
              <a href="#wallpapers" className="hover:text-indigo-400 text-gray-300 px-3 py-2 rounded-md text-sm font-medium transition-colors">Wallpapers</a>
              <a href="#templates" className="hover:text-indigo-400 text-gray-300 px-3 py-2 rounded-md text-sm font-medium transition-colors">Templates</a>
              <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-full text-sm font-medium transition-colors flex items-center gap-2">
                <ShoppingCart className="w-4 h-4" />
                Cart (0)
              </button>
            </motion.div>
          </div>
          
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none"
            >
              {isOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="md:hidden bg-gray-900 border-b border-white/10"
        >
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#home" className="hover:text-white text-gray-300 block px-3 py-2 rounded-md text-base font-medium">Home</a>
            <a href="#wallpapers" className="hover:text-white text-gray-300 block px-3 py-2 rounded-md text-base font-medium">Wallpapers</a>
            <a href="#templates" className="hover:text-white text-gray-300 block px-3 py-2 rounded-md text-base font-medium">Templates</a>
          </div>
        </motion.div>
      )}
    </nav>
  );
}
