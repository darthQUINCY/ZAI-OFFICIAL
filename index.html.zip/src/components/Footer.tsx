import { Gamepad2, Mail, Link, Share2 } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-black border-t border-white/10 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <Gamepad2 className="w-8 h-8 text-indigo-500" />
              <span className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-500 bg-clip-text text-transparent tracking-wider">
                ZAI OFFICIAL
              </span>
            </div>
            <p className="text-gray-400 leading-relaxed max-w-sm">
              Premium destination for high-quality Mobile Legends: Bang Bang live streaming templates and stunning video wallpapers.
            </p>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-6 tracking-wider uppercase">Quick Links</h3>
            <ul className="space-y-4">
              <li><a href="#home" className="text-gray-400 hover:text-indigo-400 transition-colors">Home</a></li>
              <li><a href="#wallpapers" className="text-gray-400 hover:text-indigo-400 transition-colors">Wallpapers</a></li>
              <li><a href="#templates" className="text-gray-400 hover:text-indigo-400 transition-colors">Stream Templates</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-6 tracking-wider uppercase">Connect</h3>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-indigo-600 hover:text-white transition-all">
                <Mail className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-indigo-600 hover:text-white transition-all">
                <Link className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-indigo-600 hover:text-white transition-all">
                <Share2 className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} ZAI OFFICIAL. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
