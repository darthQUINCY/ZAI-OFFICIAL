export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  imageUrl: string;
  category: 'wallpaper' | 'template';
}

export const products: Product[] = [
  {
    id: '1',
    title: 'Gusion Cosmic Legend',
    description: 'Dynamic video wallpaper with stellar effects.',
    price: 199,
    imageUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800',
    category: 'wallpaper'
  },
  {
    id: '2',
    title: 'Chou Freestyle God',
    description: 'High-quality animated wallpaper featuring Chou.',
    price: 149,
    imageUrl: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&q=80&w=800',
    category: 'wallpaper'
  },
  {
    id: '3',
    title: 'Pro Streamer Overlay v1',
    description: 'Complete stream overlay for MLBB, includes webcam frame & alerts.',
    price: 499,
    imageUrl: 'https://images.unsplash.com/photo-1542751110-97427bbecf20?auto=format&fit=crop&q=80&w=800',
    category: 'template'
  },
  {
    id: '4',
    title: 'Mythical Glory Frame',
    description: 'Animated glowing border for your gameplay recordings.',
    price: 299,
    imageUrl: 'https://images.unsplash.com/photo-1616588589676-62b3bd4ff6d2?auto=format&fit=crop&q=80&w=800',
    category: 'template'
  },
  {
    id: '5',
    title: 'Fanny Skylark Motion',
    description: 'Smooth 60fps video wallpaper of Fanny.',
    price: 199,
    imageUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=800',
    category: 'wallpaper'
  },
  {
    id: '6',
    title: 'Minimalist Rank Overlay',
    description: 'Clean and non-intrusive stream overlay for ranked games.',
    price: 349,
    imageUrl: 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&q=80&w=800',
    category: 'template'
  }
];
