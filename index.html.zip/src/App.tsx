import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProductSection } from './components/ProductSection';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="bg-black min-h-screen text-white">
      <Navbar />
      <Hero />
      <ProductSection 
        id="wallpapers"
        title="Live Wallpapers" 
        subtitle="Bring your device to life with our premium, high-quality animated backgrounds featuring your favorite heroes."
        category="wallpaper"
      />
      <ProductSection 
        id="templates"
        title="Stream Templates" 
        subtitle="Level up your live stream with professional, customizable overlays and transition scenes."
        category="template"
      />
      <Footer />
    </div>
  );
}

export default App;
